namespace KGUI
{
    public enum UIPanelID
    {
        Error = 0,
        PlayerStatus,
        PlacementTool,
        PlacementMaterialTool,
        PotionTool,
        GameMenu
    }
}

