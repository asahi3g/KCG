using UnityEngine;

namespace KGUI
{
    public class GameMenuPanel : UIPanel
    {
        [SerializeField] private StartElementUI startButton;
        [SerializeField] private ResumeElementUI resumeButton;
        [SerializeField] private ControlsElementUI controlsButton;
        [SerializeField] private ExitElementUI exitButton;

        public override void Init()
        {
            ID = UIPanelID.GameMenu;
            
            UIElementList.Add(startButton.ID, startButton);
            UIElementList.Add(resumeButton.ID, resumeButton);
            UIElementList.Add(controlsButton.ID, controlsButton);
            UIElementList.Add(exitButton.ID, exitButton);
            
            base.Init();
        }
    }
}
